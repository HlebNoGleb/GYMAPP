var config = {};

config.db = {};

config.db.path = "mongodb://127.0.0.1:27017/gymapp";

module.exports = config;