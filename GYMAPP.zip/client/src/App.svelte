<script lang="ts">
    import Dev from "./lib/components/pages/dev.svelte";
    import Start from "./lib/components/pages/start.svelte";
</script>
<Dev />
<Start />