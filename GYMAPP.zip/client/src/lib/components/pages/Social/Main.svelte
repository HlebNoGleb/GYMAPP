<script lang="ts">
    import { _ } from 'svelte-i18n';
    import ButtonBack from '../../common/buttonBack.svelte';
</script>

<h1>Что-то социальное</h1>

<ButtonBack/>