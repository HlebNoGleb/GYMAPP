<script lang="ts">
    import { _ } from 'svelte-i18n';
    import ButtonBack from '../common/buttonBack.svelte';
</script>

<h1>Страница регистрация</h1>


<ButtonBack/>